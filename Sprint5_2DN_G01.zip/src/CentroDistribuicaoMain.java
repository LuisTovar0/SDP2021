import CentroDistribuicao.CentroDistribuicao;

import java.io.IOException;

public class CentroDistribuicaoMain {
	public static void main(String[] args) throws IOException {
		new CentroDistribuicao();
	}
}
