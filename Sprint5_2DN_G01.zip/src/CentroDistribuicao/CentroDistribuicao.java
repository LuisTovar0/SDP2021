package CentroDistribuicao;

import sdp2021.Client;
import sdp2021.SDP;
import sdp2021.Server;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.concurrent.Semaphore;

public class CentroDistribuicao {
	private final AlojadoresQueue alojadores = new AlojadoresQueue();
	private final Thread serverThread,
			analisaAlojadoresThread, analisaFicheirosThread;
	private final Semaphore semFolder = new Semaphore(1);

	public CentroDistribuicao() throws IOException {
		serverThread = Server.getInstance(semFolder).start();
		analisaAlojadoresThread = analisarNovosAlojadores();
		analisaFicheirosThread = analisarFicheiros();
	}

	public void stop() {
		serverThread.interrupt();
		analisaAlojadoresThread.interrupt();
		analisaFicheirosThread.interrupt();
	}

	/**
	 * <p>verifica se há novos ficheiros para enviar, e envia-os</p>
	 * todo:
	 * <ul>
	 * <li>uma thread a analisar a pasta de ficheiros recebidos</li>
	 * <li>quendo é encontrado um novo ficheiro, lançar uma nova thread que chama o método {@link CentroDistribuicao#sendFile(String)}</li>
	 * </ul>
	 */
	private Thread analisarFicheiros() {
		Thread thread = new Thread(() -> {
			System.out.println("analisando ficheiros recebidos de clientes emissores");
			File serverStorageDir = new File(Server.dir);
			while (!Thread.interrupted()) {
				try {
					semFolder.acquire();
				} catch (InterruptedException e) {
					return;
				}
				String[] contents = serverStorageDir.list();
				if (contents != null) {
					LinkedList<String> c = new LinkedList<>();
					Collections.addAll(c, contents);
					c.remove("infos");
					if (c.size() > 0) {
						System.out.println("a enviar " + Server.dir + c.getFirst());
						sendFile(Server.dir + c.getFirst());
					}
				}
				semFolder.release();
			}
		});
		thread.start();
		return thread;
	}

	/**
	 * realiza ciclo infinito sobre um ficheiro onde estão listados os alojadores
	 * e adiciona os novos à rotating queue
	 */
	private Thread analisarNovosAlojadores() {
		Thread thread = new Thread(() -> {
			System.out.println("analisando alojadores");
			Scanner fileScanner;
			try {
				//noinspection ResultOfMethodCallIgnored
				Server.alojadoresFile.createNewFile();
				fileScanner = new Scanner(Server.alojadoresFile);
			} catch (IOException e) {
				e.printStackTrace();
				return;
			}
			while (!Thread.interrupted()) {
				synchronized (Server.alojadoresFile) {
					if (fileScanner.hasNextLine()) {
						try {
							String line = fileScanner.nextLine();
							InetAddress ip = InetAddress.getByName(line);
							alojadores.add(ip);
						} catch (Exception ex) {
							ex.printStackTrace();
							return;
						}
					} else {
						try {
							fileScanner = new Scanner(Server.alojadoresFile);
						} catch (FileNotFoundException e) {
							e.printStackTrace();
							return;
						}
					}
				}
			}
		});
		thread.start();
		return thread;
	}

	private void sendFile(String fileName) {
		File file = new File(fileName);
		if (!file.exists()) {
			System.out.println("ficheiro não existe");
			return;
		}
		while (true) {
			InetAddress ipAlojador = alojadores.next();
			if (ipAlojador != null) {
				Client client;
				try {
					client = new Client(ipAlojador, Server.port);
					client.sendFile(fileName, fileName);
					client.fechaLigacao();
					System.out.println(file.delete()
							? "ficheiro enviado e apagado"
							: "ficheiro enviado mas não apagado");
					break;
				} catch (IOException ex) {
					alojadores.notAvailable(ipAlojador);
				}
			}
		}
	}

}
